CREATE DATABASE  IF NOT EXISTS `rpavan` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci */ /*!80016 DEFAULT ENCRYPTION='N' */;
USE `rpavan`;
-- MySQL dump 10.13  Distrib 8.0.33, for Win64 (x86_64)
--
-- Host: localhost    Database: rpavan
-- ------------------------------------------------------
-- Server version	8.0.33

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `usuario`
--

DROP TABLE IF EXISTS `usuario`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `usuario` (
  `idusuario` int NOT NULL AUTO_INCREMENT,
  `nome` varchar(45) DEFAULT NULL,
  `sobrenome` varchar(45) DEFAULT NULL,
  `email` varchar(100) DEFAULT NULL,
  `cpf` bigint DEFAULT NULL,
  `datas` date DEFAULT NULL,
  `celular` bigint DEFAULT NULL,
  `senha` varchar(255) DEFAULT NULL,
  `genero` varchar(20) DEFAULT NULL,
  `tipo` tinyint(1) DEFAULT '1',
  `cep` int DEFAULT NULL,
  PRIMARY KEY (`idusuario`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `usuario`
--

LOCK TABLES `usuario` WRITE;
/*!40000 ALTER TABLE `usuario` DISABLE KEYS */;
INSERT INTO `usuario` VALUES (1,'Luany','Freitas','luany@gmail.com',78965412305,'2003-07-14',31990697811,'luany','Feminino',1,NULL),(6,'nathan','costa','undegor@gmail.com',123456789,'2002-11-16',123456798,'$2y$10$S44SOzINuEUWR2zo/BhfmOOwW4840fCIZTv9XAQstLRmu/PX6n38m','Masculino',0,NULL),(7,'Luany','a','a@gmai.com',12341234,'2015-12-16',12354879,'$2y$10$yLChjScTIlxB14c4OK5TX.aUQBhum6ZW9F1tK8e5wqAk4v0EtRho2','Feminino',1,NULL),(8,'nathan','123','nathan@gmail.com',123456987,'2013-12-15',12345678,'$2y$10$EGKZTta1KqwQl2duB8jImukh9Ta6mmChY4jeFZwKkArEI/XY1IV0u','Feminino',1,NULL),(9,'teste','teste','admin@gmail.com',123456789,'2001-05-16',123456897,'$2y$10$0edtQPoMI2TFFskm..JhQ.zHSmOkK/sjuNQsQTOSBdyH2ujQpv4bW','Masculino',0,NULL);
/*!40000 ALTER TABLE `usuario` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-12-11 11:52:50
